package vacinationprogram;

/**
 *
 * @author Luke Ferrie
 */
public class Patient {
    private String name;
    private String age;
    private String medicalCondition;
    private int priority;
    
    public Patient(){
        name=new String();
        age=new String();
        medicalCondition=new String();
        priority= 0;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public void setMedicalCondition(String medicalCondition) {
        this.medicalCondition = medicalCondition;
    }   

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }
    
    
}
