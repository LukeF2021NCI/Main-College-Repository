package vacinationprogram;

/**
 *
 * @author Luke Ferrie
 */
public class VacinationProgram {

    public static void main(String[] args) {
        VacinationProgramGUI CAapp = new VacinationProgramGUI();
        CAapp.setVisible(true);
    }
    
}
