package garageapp;

import java.io.Serializable;

/**
 * 03/01/2020
 * @author Luke Ferrie X19476134
 */
public class Garage implements Serializable {

    //Declaring Data Members
    private String make;
    private String registration;
    private int price;
    private int vrt;
    private int milage;

    //Creating the constructor
    public Garage() {
        make = "";
        registration = "";
        price = 0;
        vrt = 0;
        milage = 0;
    }
    
    //Creating setters and getters

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getRegistration() {
        return registration;
    }

    public void setRegistration(String registration) {
        this.registration = registration;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getVrt() {
        return vrt;
    }

    public void setVrt(int vrt) {
        this.vrt = vrt;
    }

    public int getMilage() {
        return milage;
    }

    public void setMilage(int milage) {
        this.milage = milage;
    }
    
    public String getDetails(){
        return "Make: "+make+"\nRegistration: "+registration+"\nPrice: "+price+"\nVrt: "+vrt+"\nMilage: "+milage;
    }
    
    //@reference: All work is of my own doing, no external resources used//
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
