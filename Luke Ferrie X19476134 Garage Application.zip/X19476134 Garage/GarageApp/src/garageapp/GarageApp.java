package garageapp;

/**
 * 03/01/2020
 * @author Luke Ferrie X19476134
 */
public class GarageApp {

    //Establishing my GUI and setting its visablity to be true
    public static void main(String[] args) {
        
        GarageGUI gui = new GarageGUI();
        gui.setVisible(true);
    }
    
}
